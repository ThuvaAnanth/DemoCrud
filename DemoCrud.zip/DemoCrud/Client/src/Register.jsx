import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import{Link} from 'react-router-dom'
import axios from 'axios'

function Login() {
    const[name,setName] = useState()
    const[email,setEmail] = useState()
    const[password,setPassword] = useState()
    const navigate = useNavigate()



    const handleSubmit = (e)=>{
        e.preventDefault()
        axios.post('http://localhost:5173/register',{name,email,password})
        .then(result => {console.log(result)
        if(result.data=== "success"){
            alert(" Registration  successfully!");
            navigate("/")
        }
        })
        .catch(err=>console.log(err))
    }


  return (
<div className='flex justify-center items-center h-screen bg-secondary'>
    <div className='bg-red-300 p-6 rounded w-2/4'>
        <h2 className='text-4xl text-gray-900 font-bold mb-4'>Register</h2>
        <form onSubmit={handleSubmit} className='space-y-4'>
            <div className=''>
                <label htmlFor='name' className='block text-sm font-medium text-gray-700'>
                    Name
                </label>
                <input
                    type='text'
                    placeholder='Enter the name'
                    autoComplete='off'
                    name='name'
                    className='form-input rounded border py-2 px-3 w-full'
                    onChange={(e) => setName(e.target.value)}
                />
            </div>
            <div className=''>
                <label htmlFor='email' className='block text-sm font-medium text-gray-700'>
                    Email
                </label>
                <input
                    type='email'
                    placeholder='Enter the email'
                    autoComplete='off'
                    name='email'
                    className='form-input rounded border py-2 px-3 w-full'
                    onChange={(e) => setEmail(e.target.value)}
                />
            </div>
            <div className=''>
                <label htmlFor='password' className='block text-sm font-medium text-gray-700'>
                    Password
                </label>
                <input
                    type='password'
                    placeholder='Enter the password'
                    name='password'
                    className='form-input rounded border py-2 px-3 w-full'
                    onChange={(e) => setPassword(e.target.value)}
                />
            </div>
            <button type='submit' className='bg-green-500 text-white py-2 px-4 rounded-md w-full hover:bg-green-900'>
                Register
            </button>
        </form>
        <p className='font-semibold mt-4'>If you have an account</p>
        <Link to='/' className='bg-blue-500 text-white py-2 px-4 rounded-md inline-block mt-2  hover:bg-blue-900'>
            Login
        </Link>
    </div>
</div>

  )
}

export default Login